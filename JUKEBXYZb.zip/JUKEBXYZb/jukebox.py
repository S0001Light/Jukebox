# change paths to all folders need to run for ogg player
# made from only help of reading will mcGugan book on Beginning Game Development with Python and Pygame, alone, and fixed out of broken book.
# peace good book...
# all music I created with this share.
# spence.shawn@gmail.com

SCREEN_SIZE = (500, 250)
# folder of music on computer
MUSIC_PATH = 'D:/Documents/workFiles/scsNewFolder/JUKEBXYZb/ogg'
jokerA = 'D:/Documents/workFiles/scsNewFolder/JUKEBXYZb/img/jkr1.png'

import pygame
from pygame.locals import *
from math import sqrt
from random import randint
import os
import os.path
from sys import exit


def get_music(path):
    global MUSIC_PATH
    # get the filenames from the folder
    raw_filenames = os.listdir(path)
    music_files = []
    for filename in raw_filenames:
        if filename.endswith('.ogg'):
            music_files.append(os.path.join(MUSIC_PATH, filename))
    
    return sorted(music_files)

class Button(object):

    def __init__(self, image_filename, position):
        self.position = position
        self.image = pygame.image.load(image_filename)
    def render(self, surface):
        # render near the center
        x, y = self.position
        w, h = self.image.get_size()
        x -= w / 2
        y -= h / 2
        surface.blit(self.image, (x, y))
    def is_over(self, point):
        # returns true if a point is over the button
        point_x, point_y = point
        x, y = self.position
        w, h = self.image.get_size()
        x -= w / 2
        y -= h / 2
        in_x = point_x >= x and point_x < x + w
        in_y = point_y >= y and point_y < y + h

        return in_x and in_y

pygame.mixer.pre_init(44100, -16, 2, 4096)
pygame.init()
screen = pygame.display.set_mode(SCREEN_SIZE, RESIZABLE, 32)
jokerB = pygame.image.load(jokerA).convert_alpha()

# creates the buttons
x = 40
y = 64

button_width = 20
# stores buttons in a dictionary, so they can be assigned names
buttons = {}
buttons['prev'] = Button('D:/Documents/workFiles/scsNewFolder/JUKEBXYZb/img/prev.png', (x*2, y))
buttons['pause'] = Button('D:/Documents/workFiles/scsNewFolder/JUKEBXYZb/img/pause.png', (x+button_width*5, y))
buttons['stop'] = Button('D:/Documents/workFiles/scsNewFolder/JUKEBXYZb/img/stop.png', (x+button_width*7.5, y))
buttons['play'] = Button('D:/Documents/workFiles/scsNewFolder/JUKEBXYZb/img/play.png', (x+button_width*11, y))
buttons['next'] = Button('D:/Documents/workFiles/scsNewFolder/JUKEBXYZb/img/next.png', (x+button_width*15, y))

# gets a list from the files music path
music_filenames = get_music(MUSIC_PATH)

music_paths = str()
music_paths = "".join(repr(music_filenames).replace("D:/Documents/workFiles/scsNewFolder/JUKEBXYZb/ogg/", ""))

if len(music_filenames) == 0:
    print('Apologies, there are no OGG files in the music path', MUSIC_PATH)
else:
    print('.ogg files, detected.')
font = pygame.font.SysFont('D:/Documents/workFiles/scsNewFolder/JUKEBXYZb/aFont.ttf', 64);
white = (255, 255, 255)
label_surfaces = []
# renders the track names
a = 0
while a in range(0, len(music_filenames)):
    for filename in music_filenames:
        a += 1
        txt = os.path.split(filename)[-1]
        print('Track:', a, txt)
        txt = txt.split('.')[0]
        surface = font.render(txt, True, (255,255,255))
        label_surfaces.append(surface)

current_track = 1
max_tracks = len(music_filenames)
print(max_tracks)
for current_track in range(0, max_tracks):
# loads the first track
    current_track = (current_track + 1) % max_tracks
    pygame.mixer.music.load(music_filenames[current_track])
clock = pygame.time.Clock()
playing = False
paused = False
# the event that is sent when a music track ends
TRACK_END = USEREVENT + 1
pygame.mixer.music.set_endevent(TRACK_END)

while True:
    button_pressed = None
    for event in pygame.event.get():
        if event.type == QUIT:
            pygame.quit()
        if event.type == MOUSEBUTTONDOWN:
            # finds the pressing of a button
            for button_name, button in buttons.items():
                if button.is_over(event.pos):
                    print(button_name, ' Pressed')
                    button_pressed = button_name
                    if button_pressed == 'next':
                        
                        current_track = (current_track + 1) % max_tracks
                        print('Next Track', current_track)
                        pygame.mixer.music.load(music_filenames[current_track])
                        pygame.mixer.music.play()
                        if playing:
                            pygame.mixer.music.play()
                    elif button_pressed == 'prev':
                        
                        current_track = (current_track - 1) % max_tracks
                        print('Previous Track', current_track)
                        pygame.mixer.music.load(music_filenames[current_track])
                        pygame.mixer.music.play()
                        if playing:
                            pygame.mixer.music.play()
                    elif button_pressed == 'pause':
                        if paused:
                            print('Unpause')
                            pygame.mixer.music.unpause()
                            paused = False
                        else:
                            print('Paused')
                            pygame.mixer.music.pause()
                            paused = True
                    elif button_pressed == 'stop':
                        print('Stop')
                        pygame.mixer.music.stop()
                        playing = False
                        
                    elif button_pressed == 'play':
                        if paused:
                            print('Play, after Pause')
                            pygame.mixer.music.play()
                            playing = True
                        else:
                            print('Play')
                            pygame.mixer.music.play()
                            playing = True
                    break
    
    color = (randint(50, 205), randint(50, 205), randint(50, 205))
    screen.fill((0,0,0))
    
    def line1():
        rand_color = (randint(0, 0), randint(0, 10), randint(200, 225))
        a = 1
        while a in range(0, 480):
                a += 1
                b = 1
                while b in range(-250, 250):
                        b += 1
                        c = (a, b)
                        screen.set_at(c,rand_color)
        return

    def line4():
        rand_color = ((0,0,83))
        a = 1
        while a in range(0, 470):
                a += 1
                b = 1
                while b in range(-250, 250):
                        b += 1
                        c = (a, b)
                        screen.set_at(c,rand_color)
        return

    def line2():
        rand_color = ((0,0,0))
        a = 1
        while a in range(0, 500):
                a += 1
                b = 1
                while b in range(0, 20):
                        b += 1
                        c = (a, b)
                        screen.set_at(c,rand_color)
        return

    def line3():
        rand_color = ((0,0,0))
        a = 1
        while a in range(0, 20):
                a += 1
                b = 1
                while b in range(0, 250):
                        b += 1
                        c = (a, b)
                        screen.set_at(c,rand_color)
        return
    
    def line5():
        rand_color = (randint(0, 0), randint(0, 10), randint(200, 225))
        a = 1
        while a in range(0, 30):
                a += 1
                b = 1
                while b in range(0, 250):
                        b += 1
                        c = (a, b)
                        screen.set_at(c,rand_color)
        return
    
    line1()
    line4()
    line2()
    line5()
    line3()
    
    
    
    # renders the names of the current track
    label = label_surfaces[current_track]
    w, h = label.get_size()
    screen_w = SCREEN_SIZE[0]
    screen.blit(label, ((screen_w - w) / 2, 140))
    
    # renders all the buttons
    for button in buttons.values():
        button.render(screen)
    
    # without animation, 5 frames per second works fine
    clock.tick(5)
    
    screen.blit(jokerB, (x*9.5, y+20))
    
    pygame.display.update()

